<div align="center">

<h1>🗄️ My First Linux Backup Script</h1>

<p><b>Compress. Timestamp. Clean up. Repeat every night at 2 AM, all on its own.</b></p>

<img src="https://img.shields.io/badge/Bash-Script-4EAA25?style=for-the-badge&logo=gnubash&logoColor=white" alt="Bash">
<img src="https://img.shields.io/badge/Linux-WSL%20%7C%20Ubuntu-FCC624?style=for-the-badge&logo=linux&logoColor=black" alt="Linux">
<img src="https://img.shields.io/badge/Automation-Cron-0A66C2?style=for-the-badge" alt="Cron">
<img src="https://img.shields.io/badge/Level-Beginner-2EA44F?style=for-the-badge" alt="Beginner">

<br><br>

<img src="images/setup-and-first-run.png" alt="My terminal: setting up the project and running the first backup" width="85%">

<sub>📷 My own terminal while building this project</sub>

</div>

I built this little project to learn how Linux really works. It's a Bash script that takes a folder, squeezes it into one compressed file, stamps it with the date and time, throws away backups that are too old, and then runs on its own every night at 2 AM.

It's simple on purpose. If you're new to Linux like I was, you can follow along, type each command, and understand what every single line is doing.

## 📑 Contents

- [What it does](#what-it-does)
- [Project layout](#project-layout)
- [See it working](#see-it-working)
- [Getting started](#getting-started)
- [The setup commands, explained](#the-setup-commands-explained)
- [The script, line by line](#the-script-line-by-line)
- [Making it run by itself with cron](#making-it-run-by-itself-with-cron)
- [Checking and restoring backups](#checking-and-restoring-backups)
- [Easy things to change](#easy-things-to-change)
- [What I learned](#what-i-learned)

---

## What it does

Each time the script runs, it:

1. Looks at the folder I want to protect (`sample-data`)
2. Packs everything inside into one compressed `.tar.gz` file
3. Names that file with the exact date and time, so no backup ever overwrites another
4. Checks whether the backup actually worked
5. Deletes backups older than 7 days so the disk doesn't fill up
6. Does all of this automatically every day at 2:00 AM, thanks to cron

## Project layout

```
backup-script/
├── backup.sh        <- the backup script
├── setup.sh         <- the setup commands, in order
├── backups/         <- finished backups end up here
└── sample-data/     <- the files I'm backing up
    ├── testfile.txt
    └── file2.txt
```

---

## See it working

These are real screenshots from my own terminal.

### Step 1: Setup and my first backup

Creating the folders and files, making the script executable with `chmod +x`, and running my very first backup.

<div align="center">
<img src="images/setup-and-first-run.png" alt="Setup and first backup run" width="90%">
</div>

> [!NOTE]
> Look near the top and you'll spot my typo: `echo"This is a test file"` with no space, which gave a `command not found` error. Linux is picky about spaces, and I fixed it on the very next line.

### Step 2: Second backup, checking the folder, and scheduling with cron

I ran the script again, listed the backups folder with `ls -lh`, and set up the cron job.

<div align="center">
<img src="images/second-run-and-cron.png" alt="Second backup run, backups list and crontab" width="90%">
</div>

> [!TIP]
> Two backups now sit in the folder, each with its own timestamp, and `crontab -l` at the bottom confirms the 2 AM schedule was saved.

---

## Getting started

```bash
# make the folders
mkdir -p ~/backup-script/backups
mkdir -p ~/backup-script/sample-data

# create two sample files to back up
echo "This is a test file." > ~/backup-script/sample-data/testfile.txt
echo "This is another file for backup testing." > ~/backup-script/sample-data/file2.txt

# go into the project and make the script runnable
cd ~/backup-script
chmod +x backup.sh

# run it
./backup.sh
```

If it works, you'll see something like this:

```
Starting backup...
tar: Removing leading `/' from member names
Backup successful!
Backup saved to: /home/laptopmaryam/backup-script/backups/backup_2026-10-03_02-22-31.tar.gz
Deleting backups older than 7 days...
Backup process completed.
```

---

## The setup commands, explained

**`pwd`**
Stands for *print working directory*. It simply tells you which folder you're standing in right now. Think of Linux as a giant tree of folders, and `pwd` tells you which branch you're on.

**`mkdir -p ~/backup-script/backups`**
`mkdir` means *make directory*. The `-p` part says "also create any parent folders that are missing", so it won't complain if `backup-script` doesn't exist yet. The `~` is a shortcut for your home folder, so `~/backup-script` really means `/home/laptopmaryam/backup-script`.

**`echo "This is a test file." > testfile.txt`**
`echo` prints text. The `>` symbol redirects that text into a file instead of showing it on screen. If the file doesn't exist, it's created. If it does exist, it gets overwritten, so be careful with it.

**`cat file`**
Prints what's inside a file. I used it to make sure my text really got saved.

**`ls -R ~/backup-script`**
`ls` lists files. `-R` means recursive, so it also shows what's inside every sub-folder. It's a quick way to see the whole project at once.

**`cd ~/backup-script`**
*Change directory.* It moves you into the project folder.

**`nano backup.sh`**
Opens the Nano text editor so I can write the script. To save: `CTRL + O`, then `ENTER`. To leave: `CTRL + X`.

**`chmod +x backup.sh`**
Every Linux file has permissions: read (`r`), write (`w`) and execute (`x`). A brand new file can't be run as a program. `chmod +x` adds the execute permission. You can check it with `ls -l backup.sh`. When you see `-rwxr-xr-x`, those `x` letters mean it's runnable.

---

## The script, line by line

### The first line (shebang)
```bash
#!/bin/bash
```
This tells Linux which program should run the file: Bash. Without it, the system might try a different shell and things could break.

### Variables
```bash
SOURCE_DIR="$HOME/backup-script/sample-data"
BACKUP_DIR="$HOME/backup-script/backups"
```
Variables are like labelled boxes that hold a value. `SOURCE_DIR` holds the folder I want to back up, and `BACKUP_DIR` holds the place where backups are stored. `$HOME` is built into Linux and points to your home folder, so the script isn't tied to my username. One thing that surprised me: there must be **no spaces** around the `=` sign in Bash.

### The timestamp
```bash
DATE=$(date +%Y-%m-%d_%H-%M-%S)
```
The `$( ... )` part runs a command and saves what it prints. Here it runs `date` with a custom format: year, month, day, hour, minute, second. The result looks like `2026-10-03_02-22-31`.

### The backup name
```bash
BACKUP_NAME="backup_$DATE.tar.gz"
```
This glues the word `backup_` to the timestamp, giving something like `backup_2026-10-03_02-22-31.tar.gz`. Because the time is different every second, every backup gets its own unique name.

### How long to keep backups
```bash
RETENTION_DAYS=7
```
Backups older than this many days will be deleted. Want to keep them for a month? Just change 7 to 30.

### Telling me it started
```bash
echo "Starting backup..."
```
A simple message so I know the script has begun.

### Making sure the backup folder exists
```bash
mkdir -p "$BACKUP_DIR"
```
If I ever delete the `backups` folder by accident, this recreates it. If it already exists, nothing happens and there's no error. The quotes around the variable protect the path in case it ever has spaces in it.

### The main part: tar
```bash
tar -czf "$BACKUP_DIR/$BACKUP_NAME" "$SOURCE_DIR"
```
`tar` bundles many files into one archive. The letters after the dash each do something:

| Option | What it means |
|--------|---------------|
| `c` | **Create** a new archive |
| `z` | Compress it with **gzip** to make it smaller |
| `f` | The next thing I type is the **file** name of the archive |

So this line says: *take everything in `sample-data`, pack it up, compress it, and save it in the backups folder with the timestamped name.*

About that message, `tar: Removing leading '/' from member names`: it looks scary but it's not an error. tar just strips the starting `/` from the stored paths as a safety feature, so restoring a backup can never accidentally overwrite important system files.

### Did it work?
```bash
if [ $? -eq 0 ]
then
    echo "Backup successful!"
    echo "Backup saved to: $BACKUP_DIR/$BACKUP_NAME"
else
    echo "Backup failed!"
    exit 1
fi
```
`$?` holds the result of the last command. In Linux, `0` means success and anything else means something went wrong. So the script asks "was the result 0?" If yes, it prints the success messages. If not, it says the backup failed and `exit 1` stops the script right there. That stop matters: without it, the cleanup step below could delete my old backups even though no new one was made.

### Cleaning up old backups
```bash
find "$BACKUP_DIR" -name "*.tar.gz" -type f -mtime +$RETENTION_DAYS -exec rm {} \;
```
This is the longest line, so here it is in pieces:

| Piece | What it means |
|-------|---------------|
| `find "$BACKUP_DIR"` | Search inside the backups folder |
| `-name "*.tar.gz"` | Only files that end in `.tar.gz` |
| `-type f` | Only regular files, not folders |
| `-mtime +7` | Only files last modified more than 7 days ago |
| `-exec rm {} \;` | Delete each file it finds (`{}` stands for the file name) |

Since it only matches `.tar.gz` files inside the backups folder, it can't touch anything else.

### Wrapping up
```bash
echo "Backup process completed."
```
Just a final message to say everything finished.

---

## Making it run by itself with cron

Cron is the scheduler built into Linux. To edit my schedule:

```bash
crontab -e
```

The first time, it asks which editor to use. I picked `1` (nano) because it's the easiest. Then I added this line:

```
0 2 * * * /home/laptopmaryam/backup-script/backup.sh
```

Here's how to read it:

```
0   2   *   *   *   /home/laptopmaryam/backup-script/backup.sh
|   |   |   |   |
|   |   |   |   +-- day of the week (* = every day)
|   |   |   +------ month (* = every month)
|   |   +---------- day of the month (* = every day)
|   +-------------- hour (2 = 2 AM)
+------------------ minute (0 = right on the hour)
```

In plain words: *every day at 2:00 AM, run my backup script.* To double check it was saved, run `crontab -l`.

Two small things I learned:

- Always use the **full path** in a cron job. Cron doesn't run in your normal terminal environment, so shortcuts like `~` aren't reliable there.
- I'm on WSL (Linux inside Windows), and cron doesn't always start on its own there. If the job never runs, start it with `sudo service cron start`.

---

## Checking and restoring backups

To see your backups with readable sizes:

```bash
ls -lh backups/
```

`-l` gives the detailed list and `-h` makes the sizes human-readable.

To look inside a backup without unpacking it:

```bash
tar -tzf backups/backup_2026-10-03_02-22-31.tar.gz
```

To restore one into a folder (make the folder first with `mkdir ~/restored`):

```bash
tar -xzf backups/backup_2026-10-03_02-22-31.tar.gz -C ~/restored/
```

`x` means extract, and `-C` says which folder to extract into.

---

## Easy things to change

| I want to... | Change this |
|--------------|-------------|
| Back up a different folder | `SOURCE_DIR` |
| Store backups somewhere else | `BACKUP_DIR` |
| Keep backups longer or shorter | `RETENTION_DAYS` |
| Run at a different time | The cron line (`0 2 * * *`) |

---

## What I learned

- Moving around the Linux file system with `pwd`, `cd`, `ls` and `mkdir`
- Creating files with `echo` and `>`
- File permissions and `chmod`
- Bash variables, command substitution and `if / else`
- Checking success or failure with exit codes (`$?`)
- Compressing folders with `tar`
- Finding and deleting files by age with `find`
- Scheduling jobs with `cron`

If this helped you, a ⭐ on the repo would make my day!
